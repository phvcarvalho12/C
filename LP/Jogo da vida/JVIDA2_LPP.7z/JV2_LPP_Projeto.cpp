//JV_LPP_Projeto.cpp
//10/10/2023
//Grupo: LPP
//Larissa Hipolito, Pedro Gabriel, Pedro Carvalho 

#include "JV2_LPP_Model.cpp"
#include "JV2_LPP_Controller.cpp"

int main()
{
	matrizgg();
	menuprincipal();
	return 0;
}
	

