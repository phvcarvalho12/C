//JV_LPP_View.h
//10/10/2023
//Grupo: LPP
//Larissa Hipolito, Pedro Gabriel, Pedro Carvalho 
void apresentaMensagem(char mens[100]);
int menu();

void MostraLvivo();
void MostraLmorto();